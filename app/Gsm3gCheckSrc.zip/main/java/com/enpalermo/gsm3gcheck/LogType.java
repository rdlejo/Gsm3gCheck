package com.enpalermo.gsm3gcheck;

/**
 * Created by Ricardo on 01/05/2015.
 */
public enum LogType{
    Info,Error,Debug,Verbose
}
